const events = [
{type:'cosmic',context:true,date:'~13.8 billion years ago',title:'Universe begins',summary:'The Universe begins expanding from an extremely hot, dense early state. Hydrogen and helium dominate the earliest matter.',why:'This creates the physical setting from which stars, planets, chemistry and eventually life become possible.',flow:'Universe → stars → heavier elements',details:['The “Big Bang” is not an explosion into empty space; it describes the early expansion of space itself.']},
{type:'cosmic',context:true,date:'~13.6–13.0 billion years ago',title:'First stars and galaxies',summary:'Early stars ignite. Fusion inside stars and later stellar explosions create and disperse many heavier elements.',why:'Carbon, oxygen, nitrogen, silicon, iron and other elements needed for rocky planets and life are forged through stellar evolution.',flow:'Stars make ingredients for later solar systems'},
{type:'cosmic',context:true,date:'~4.6 billion years ago',title:'Sun and Solar System form',summary:'A cloud of interstellar gas and dust collapses. The Sun forms at the center while the surrounding disk produces planetesimals and planets.',why:'The material inherited from earlier stars becomes organized into our Solar System.',flow:'Solar nebula → Sun + planets'},
{type:'earth',context:true,date:'~4.54 billion years ago',title:'Earth forms',summary:'Rocky material in the inner Solar System accretes into the young Earth.',why:'Earth becomes the planetary setting for the biological story.',flow:'Young Earth → cooling crust and oceans'},
{type:'earth',context:true,date:'~4.5 billion years ago',title:'Moon forms',summary:'The leading model involves a giant impact early in Earth’s history, followed by accretion of orbiting debris.',why:'The Moon becomes a major part of Earth’s long-term planetary history.'},
{type:'earth',context:true,date:'By ~4.4 billion years ago',title:'Early crust and liquid water',summary:'Ancient minerals indicate that parts of Earth’s crust and liquid water existed surprisingly early.',why:'Liquid water provides an important environment for prebiotic chemistry and early life.'},
{type:'life',date:'Perhaps ~4.3–4.2 billion years ago (?)',title:'Origin of life',major:true,summary:'Some form of prebiotic chemistry crossed the threshold into evolving biological systems. Exactly how, where and when this happened remains unknown.',why:'This is the beginning of biology, but it is not yet the point from which all modern cellular life can be traced.',uncertainty:'Highly uncertain. This is a perhaps-date for perspective, not a known date. Life must predate LUCA, which one recent molecular-clock study places at ~4.2 Ga.',flow:'Prebiotic chemistry ? → early evolving systems',details:[`What Is Life? Before we can explore the Tree of Life, we first need to answer a simple question: What is life?`,`A simple scientific definition is: “Life is a self-maintaining system that uses energy, responds to its environment, reproduces, and has the capacity to evolve.”`,`Scientists do not have one universally accepted definition of life, but they generally agree that all living organisms share a common set of characteristics. A simple way to remember these characteristics is with the mnemonic HORGASM.`,`H – Homeostasis: Maintains a stable internal environment.`,`O – Organization: Is composed of one or more cells, the basic units of life.`,`R – Reproduction: Produces new organisms and passes genetic information to the next generation.`,`G – Growth: Increases in size and develops throughout its life cycle.`,`A – Adaptation: Populations evolve over generations, improving their ability to survive and reproduce.`,`S – Response to Stimuli: Detects and responds to changes in the environment.`,`M – Metabolism: Obtains, transforms, and uses energy and matter to build, maintain, and power the organism.`]},
{type:'life',date:'Perhaps ~4.25–4.2 Ga (?)',title:'FUCA-type stage (?)',summary:'FUCA (“First Universal Common Ancestor”) is a proposed label for a very early ancestral stage near the emergence of the genetic code and cellular life.',why:'It helps distinguish the hypothetical earliest shared biological ancestry from LUCA, which is the last shared ancestor of living cellular lineages.',uncertainty:'FUCA is a hypothetical concept, not a securely dated organism or fossil.',flow:'Possibly hundreds of millions of years of early evolution → LUCA'},
{type:'life',date:'~4.2 billion years ago (recent estimate: ~4.33–4.09 Ga)',title:'LUCA — Last Universal Common Ancestor',major:true,summary:'The ancestral population from which all cellular life alive today ultimately descends. LUCA was not the first life.',why:'LUCA is the first major anchor for reconstructing the tree of life.',flow:'LUCA → Bacteria + Archaea',details:['Likely had DNA and RNA','Universal genetic code','Ribosomes and protein synthesis','ATP-based energy metabolism and ATP synthase','Cellular membrane and ion gradients','Basic metabolic pathways and reproduction','Did NOT have a nucleus, mitochondria or chloroplasts']},
{type:'life',date:'Perhaps ~4.1–3.5 billion years ago',title:'The Great Split — Bacteria and Archaea',major:true,summary:'Descendants of the universal ancestral population diverged into the two fundamental prokaryotic domains: Bacteria and Archaea.',why:'These two lineages remain distinct today, and both later contribute crucial pieces to the eukaryotic story.',uncertainty:'Highly uncertain. The deepest split must follow LUCA, and published molecular-clock approaches place very early bacterial/archaeal divergences across a broad Hadean-to-Paleoarchean interval. The perhaps-range is included for perspective.',flow:'Bacteria ← ancestral split → Archaea',details:['Bacteria: membranes with ester-linked fatty acids; cell walls commonly contain peptidoglycan.','Archaea: ether-linked membrane lipids; no peptidoglycan; information-processing machinery has important similarities to eukaryotes.','Living bacterial examples: cyanobacteria, E. coli, Bacillus, Streptococcus.','Living archaeal examples: methanogens, halophiles, thermophiles, ammonia-oxidizers and Asgard archaea.']},
{type:'life',date:'By ~2.7 billion years ago; possibly earlier',title:'Cyanobacteria and oxygenic photosynthesis',summary:'Cyanobacteria evolve photosynthesis that uses water and releases molecular oxygen (O₂).',why:'Biology begins altering the planet on a global scale. Early oxygen is initially consumed by reduced iron, volcanic gases and other oxygen sinks.',uncertainty:'Oxygenic photosynthesis predates the GOE; estimates for its origin extend substantially earlier than 2.7 Ga.',flow:'Cyanobacteria → O₂ production → planetary oxygenation'},
{type:'earth',date:'~2.45–2.3 billion years ago',title:'Great Oxidation Event',major:true,summary:'Atmospheric oxygen rises from extremely low pre-GOE levels and becomes a persistent component of the atmosphere.',why:'Oxygen transforms Earth’s surface chemistry and expands ecological opportunities for aerobic energy metabolism.',flow:'Near-anoxic atmosphere → persistent atmospheric O₂',details:['Before the GOE, atmospheric O₂ was probably below 10⁻⁵ of the present atmospheric level.','Today O₂ is about 21% of the atmosphere.','The exact peak O₂ concentration during and soon after the GOE remains strongly debated; the app therefore avoids presenting one precise percentage.']},
{type:'earth',context:true,date:'~2.4–2.2 billion years ago',title:'Major Paleoproterozoic glaciations',summary:'Large glaciations occur around the broad interval of planetary oxygenation and major atmospheric change.',why:'A reminder that biological and planetary evolution are interacting, not occurring separately.'},
{type:'life',date:'~2.37–1.80 billion years ago (broad molecular-clock window)',title:'Mitochondrial endosymbiosis',major:true,summary:'An archaeal host related to the lineage that includes Asgard archaea forms a permanent partnership with an alphaproteobacterial relative capable of aerobic respiration.',why:'The bacterial partner becomes the mitochondrion, a defining feature of the eukaryotic lineage and a major expansion of cellular energy-processing capacity.',uncertainty:'The exact date and sequence of steps in eukaryogenesis remain debated; recent molecular-clock work places mitochondrial acquisition before LECA within this broad interval.',flow:'Archaeal host + alphaproteobacterial partner → mitochondrion',details:['Evidence for bacterial ancestry: mitochondrial DNA, bacterial-type ribosomes, double membrane, division by fission and phylogenetic affinity to Alphaproteobacteria.','For clarity, this app calls this “mitochondrial endosymbiosis”; “primary endosymbiosis” is reserved for plastid origin.']},
{type:'life',date:'~1.80–1.67 billion years ago (one recent estimate)',title:'LECA — Last Eukaryotic Common Ancestor',major:true,summary:'The ancestral population from which all living eukaryotic lineages descend. LECA was not the first eukaryote.',why:'By LECA, the core architecture of the modern eukaryotic cell was already highly developed.',uncertainty:'Molecular-clock estimates vary; published ranges extend more broadly than the interval shown here.',flow:'LECA → major eukaryotic diversification',details:['Mitochondria','Nucleus and linear chromosomes','Complex cytoskeleton','Internal membrane systems','Vesicle trafficking','Mitosis','Probably meiosis and sexual reproduction','Flagellar/ciliary machinery']},
{type:'life',date:'Perhaps ~1.8–1.5 billion years ago',title:'Major eukaryotic diversification',major:true,summary:'Soon after LECA, the major surviving eukaryotic lineages appear to have radiated over a few hundred million years. The story now branches rather than following one straight line.',why:'Modern animals, fungi, plants, algae and numerous protist lineages are distant branches of this early diversification.',uncertainty:'Estimated from molecular clocks. A 2025 analysis inferred a rapid radiation of major eukaryotic supergroups within about 300 million years after LECA.',flow:'LECA → rapid branching → many major eukaryotic clades',details:['Living unicellular examples: amoebae, Paramecium, Euglena, dinoflagellates, diatoms, yeasts and choanoflagellates.','Modern single-celled eukaryotes are not “primitive animals”; they are their own living lineages.']},
{type:'life',date:'Probably before ~1.6 Ga; estimates extend roughly ~2.1–1.0 Ga',title:'Primary plastid endosymbiosis',major:true,summary:'A heterotrophic eukaryote permanently incorporates a cyanobacterium. The cyanobacterial partner evolves into a primary plastid — the ancestor of chloroplasts.',why:'This creates the photosynthetic lineage Archaeplastida and eventually the red-algal, green-algal and glaucophyte branches.',uncertainty:'Dating is actively debated. Different fossil calibrations and molecular clocks give substantially different estimates.',flow:'Eukaryote + cyanobacterium → primary plastid / chloroplast',details:['Chloroplast evidence for cyanobacterial ancestry includes plastid DNA, bacterial-type ribosomes, division by fission and membrane architecture.']},
{type:'life',date:'By ~1.05 billion years ago (widely accepted red-algal fossil)',title:'Red and green algal lineages',summary:'Archaeplastida diversifies into major photosynthetic lineages including red algae and the green lineage (green algae + land plants).',why:'The red lineage later becomes central to secondary endosymbiosis; the green lineage eventually gives rise to land plants.',uncertainty:'Candidate fossils may push archaeplastid/red-algal history considerably earlier, but their interpretation is debated.',flow:'Archaeplastida → red algae + green lineage'},
{type:'life',date:'Perhaps ~1.7–1.3 billion years ago (?)',title:'Secondary endosymbiosis involving a red alga',major:true,summary:'A different eukaryotic host incorporated an already photosynthetic red alga. This is eukaryote-within-eukaryote endosymbiosis rather than bacterium-within-eukaryote endosymbiosis.',why:'This began the spread of complex red-derived plastids into other eukaryotic lineages. Later transfers and diversification ultimately contributed to photosynthetic stramenopiles, including brown algae.',uncertainty:'The date and exact sequence remain debated. Molecular-clock work places the relevant red-algal donor lineage roughly 1.675–1.281 Ga and supports red-plastid transfers through the Meso- and Neoproterozoic. Some models invoke later tertiary or higher-order transfers rather than one simple direct event leading to all modern groups.',flow:'Eukaryotic host + red alga → complex red-derived plastid → later transfers → photosynthetic stramenopiles',details:['Why “secondary”? Primary endosymbiosis occurred when a eukaryote engulfed a cyanobacterium. Secondary endosymbiosis occurred later when another eukaryote engulfed an entire photosynthetic eukaryotic alga that already contained that cyanobacterium-derived plastid.','Think of it as nested ancestry: cyanobacterium → plastid inside a red alga → red alga incorporated into another eukaryotic host.','What was kept? Most importantly, the red alga’s photosynthetic plastid was retained and integrated. Many genes from the endosymbiont were transferred to, or became controlled by, the host nuclear genome.','What was lost? Most of the red alga’s independent cellular structures disappeared during integration. In the lineage leading to brown algae, the red-algal nucleus was lost rather than remaining as a separate nucleus.','An instructive exception is cryptophytes: they retain a tiny remnant red-algal nucleus called a nucleomorph, showing how much of an engulfed alga can be reduced during secondary endosymbiosis.','Why the extra membranes? A secondary plastid inherits membrane layers from its nested history, making its envelope more complex than a primary plastid.','Important scientific caution: exactly how red-derived plastids reached all modern groups remains debated. Models include one secondary event followed by losses, multiple secondary events, or serial secondary/tertiary/higher-order endosymbioses. The brown-algal story is therefore best presented as an evolutionary pathway rather than one perfectly resolved engulfment sequence.']},
{type:'life',date:'Perhaps ~1.3–0.6 billion years ago',title:'Red-derived plastids reach photosynthetic stramenopiles',summary:'During the long Proterozoic diversification of eukaryotes, the lineage leading to photosynthetic stramenopiles acquired and integrated red-algal-derived photosynthetic machinery.',why:'This establishes the deep photosynthetic ancestry from which brown algae eventually emerge.',uncertainty:'The acquisition window is broad. One molecular-clock analysis placed the stem interval for ochrophytes, the photosynthetic stramenopiles, at roughly 1.298–0.622 Ga; the precise transfer pathway remains debated.',flow:'Complex red-derived plastid → photosynthetic stramenopiles'},
{type:'life',date:'Perhaps ~500–200 million years ago (?)',title:'Brown algae diversify',summary:'Within photosynthetic stramenopiles, the brown-algal lineage develops multicellular body plans and diversifies long after the original plastid acquisitions.',why:'Brown algae are a separate eukaryotic lineage from plants even though both perform oxygenic photosynthesis.',uncertainty:'Deep brown-algal divergence dates vary substantially among molecular-clock studies; this broad perhaps-range is included to preserve chronological perspective.',flow:'Photosynthetic stramenopiles → brown algae'},
{type:'life',date:'~470–450 million years ago',title:'Land plants become established',summary:'Descendants of the green algal lineage colonize terrestrial environments and diversify as land plants.',why:'A photosynthetic lineage that began with ancient primary plastid endosymbiosis now reshapes continents and terrestrial ecosystems.',flow:'Green algal lineage → land plants'},
{type:'life',date:'~34 million years ago',title:'Kelps emerge',major:true,summary:'Large marine brown algae in the kelp lineage (Laminariales) appear comparatively late in Earth history. Fossil and molecular evidence points near the Eocene–Oligocene transition.',why:'Kelp is the late outcome of a very old chain of events: cyanobacterium → primary plastid → red alga → secondary plastid → stramenopile → brown alga → kelp.',uncertainty:'The kelp fossil record is sparse; published molecular estimates have ranged more broadly, but early Oligocene fossils support an origin around this interval.',flow:'Brown algae → kelp → modern kelp forests'},
{type:'human',context:true,date:'~8–6 million years ago',title:'Human lineage and chimpanzee/bonobo lineage share a last common ancestor',summary:'The human lineage is one branch of the ape family tree; humans did not descend from living chimpanzees.',why:'This begins the very short human-scale portion of the timeline.'},
{type:'human',context:true,date:'~2.8 million years ago',title:'Earliest Homo',summary:'The genus Homo appears in the African fossil record.',why:'Human evolutionary history remains tiny compared with the billions of years preceding it.'},
{type:'human',context:true,date:'~300,000 years ago',title:'Homo sapiens',major:true,summary:'Our species appears in Africa and later spreads worldwide.',why:'Modern humans arrive extremely late in the history of Earth and life.'},
{type:'human',context:true,date:'Within the last ~12,000 years',title:'Agriculture',summary:'Multiple human societies begin farming and herding, transforming local ecosystems and eventually much of the planet.',why:'Cultural change now occurs on timescales far faster than deep biological evolution.'},
{type:'human',context:true,date:'~5,000 years ago',title:'Writing and recorded history',summary:'Writing systems appear in several early civilizations.',why:'Nearly all written history occupies only a microscopic sliver of the full timeline.'},
{type:'human',context:true,date:'~250 years ago to today',title:'Industrial age and present day',summary:'Industrialization rapidly increases human influence on Earth systems. Modern atmospheric oxygen is ~21% by volume.',why:'The 13.8-billion-year story reaches the present.'}
];

const timeline = document.getElementById('timeline');
const contextToggle = document.getElementById('contextToggle');
const uncertaintyToggle = document.getElementById('uncertaintyToggle');
const expandAll = document.getElementById('expandAll');
let allOpen = false;

function esc(s=''){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function render(){
  timeline.innerHTML = events.map((e,i)=>{
    const details = e.details?.length ? `<details class="details" ${allOpen?'open':''}><summary>Learn more</summary><ul>${e.details.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></details>`:'';
    return `<article class="event ${e.type} ${e.context?'context':''}" data-index="${i}">
      <span class="marker" aria-hidden="true"></span>
      <div class="event-card ${e.major?'major':''}">
        <div class="kicker">${e.type}</div>
        <h2>${esc(e.title)}</h2>
        <p class="date">${esc(e.date)}</p>
        <p class="summary">${esc(e.summary)}</p>
        ${e.why?`<p class="why"><strong>Why it matters:</strong> ${esc(e.why)}</p>`:''}
        ${e.flow?`<p class="flow">${esc(e.flow)}</p>`:''}
        ${e.uncertainty?`<p class="uncertainty"><strong>Uncertainty:</strong> ${esc(e.uncertainty)}</p>`:''}
        ${details}
      </div>
    </article>`
  }).join('');
}
render();

contextToggle.addEventListener('change',()=>timeline.classList.toggle('context-hidden',!contextToggle.checked));
uncertaintyToggle.addEventListener('change',()=>timeline.classList.toggle('uncertainty-hidden',!uncertaintyToggle.checked));
document.querySelectorAll('.mode').forEach(btn=>btn.addEventListener('click',()=>{
  document.querySelectorAll('.mode').forEach(b=>b.classList.remove('active')); btn.classList.add('active');
  timeline.classList.toggle('compact',btn.dataset.mode==='compact');
}));
expandAll.addEventListener('click',()=>{allOpen=!allOpen;render();expandAll.textContent=allOpen?'Collapse all details':'Expand all details';});

let deferredPrompt;
const installBtn=document.getElementById('installBtn');
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;installBtn.hidden=false;});
installBtn.addEventListener('click',async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;installBtn.hidden=true;});

const refreshApp = document.getElementById('refreshApp');
const updateStatus = document.getElementById('updateStatus');

async function refreshToLatest(){
  refreshApp.disabled = true;
  const original = refreshApp.textContent;
  refreshApp.textContent = 'Checking…';
  updateStatus.textContent = 'Checking GitHub for the newest version…';
  try {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.getRegistration('./');
      if (reg) {
        await reg.update();
        if (reg.waiting) reg.waiting.postMessage({type:'SKIP_WAITING'});
      }
    }
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.filter(k=>k.startsWith('evolution-timeline-')).map(k=>caches.delete(k)));
    }
    updateStatus.textContent = 'Updating…';
    const url = new URL(location.href);
    url.searchParams.set('refresh', Date.now().toString());
    location.replace(url.toString());
  } catch (err) {
    updateStatus.textContent = 'Could not refresh. Check the internet connection and try again.';
    refreshApp.disabled = false;
    refreshApp.textContent = original;
  }
}
refreshApp.addEventListener('click', refreshToLatest);

if('serviceWorker' in navigator){
  window.addEventListener('load',async()=>{
    try {
      const reg = await navigator.serviceWorker.register('./sw.js');
      // Ask the browser to check GitHub for a newer service worker on each online launch.
      if (navigator.onLine) await reg.update();
    } catch (_) {}
  });
}

